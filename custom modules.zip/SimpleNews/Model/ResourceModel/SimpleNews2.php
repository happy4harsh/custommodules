<?php
namespace CP\SimpleNews\Model\ResourceModel;
use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;
class SimpleNews2 extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('news2','id');
    }
}

