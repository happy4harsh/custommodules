<?php
    
    namespace CP\SimpleNews\Observer;
 
    use Magento\Framework\Event\ObserverInterface;
    use Magento\Framework\App\RequestInterface;
 
    class Orderneo implements ObserverInterface
    {
        public function execute(\Magento\Framework\Event\Observer $observer) {
            // echo "string"; exit();
            $item = $observer->getEvent()->getData('quote_item');         
            $item = ( $item->getParentItem() ? $item->getParentItem() : $item );
            $price = $item->getProduct()->getFinalPrice()-100;
            
            $item->setCustomPrice($price);
            $item->setOriginalCustomPrice($price);
            $item->getProduct()->setIsSuperMode(true);
        }
 
    }