<?php
namespace CP\Override\Model;
class Override extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
		$this->_init('CP\Override\Model\ResourceModel\Override');
    }
}

