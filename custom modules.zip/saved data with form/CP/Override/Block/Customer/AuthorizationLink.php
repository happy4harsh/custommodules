<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CP\Override\Block\Customer;

use Magento\Customer\Model\Context;

class AuthorizationLink extends \Magento\Customer\Block\Account\AuthorizationLink
{
    public function getLabel()
    {
        return $this->isLoggedIn() ? __('Log Out') : __('Log In');
    }
    protected function _toHtml()
    {
        $this->setModuleName($this->extractModuleName('Magento\Customer\Block\Account\AuthorizationLink'));
        return parent::_toHtml();
    }
}