<?php

namespace CP\News\Controller\Adminhtml\Post;
use Magento\Framework\Exception\LocalizedException;
use Magento\Backend\App\Action;

class Delete extends \Magento\Backend\App\Action
{

    const ADMIN_RESOURCE = 'CP_News::event_delete';
    
    public function __construct(Action\Context $context)
    {
        parent::__construct($context);
    }

    public function _isAllowed()
    {
        return $this->_authorization->isAllowed(self::ADMIN_RESOURCE);
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        if ($id) {
            try {
                
                $model = $this->_objectManager->create('CP\News\Model\News');
                $model->load($id);
                $model->delete();
                $this->_redirect('news/post/index');
                $this->messageManager->addSuccess(__('Deleted News successfully.'));
                return;
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addError(
                    __('We can\'t delete this News right now. Please review the log and try again.')
                );
                $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
                $this->_redirect('News/*/edit', ['id' => $this->getRequest()->getParam('id')]);
                return;
            }
        }
        $this->messageManager->addError(__('We can\'t find a rule to delete.'));
        $this->_redirect('News/*/');
    }
}