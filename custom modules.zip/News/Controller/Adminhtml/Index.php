<?php

namespace CP\News\Controller\Adminhtml;

abstract class Index extends \Magento\Backend\App\Action
{
    protected $_coreRegistry = null;
 
    public function __construct(\Magento\Backend\App\Action\Context $context, \Magento\Framework\Registry $coreRegistry)
    {
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context);
    }
 
    protected function initPage($resultPage)
    {
        
    }
 
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('CP_News::main');
    }
}
