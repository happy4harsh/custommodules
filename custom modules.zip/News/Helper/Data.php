<?php

namespace CP\News\Helper;


use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Filesystem;
use Magento\Store\Model\StoreManager;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    /**
     * @var Filesystem
     */
    protected $_filesystem;
   
    /**
     * @var StoreManager
     */
    protected $_storeManager;

    protected $_request;

    protected $_assetRepo;

    protected $_urlBuilder;
    protected $_scopeConfig;

    /**
     * Data constructor.
     */
    public function __construct(
        Context $context,
        Filesystem $filesystem,
        ScopeConfigInterface $scopeConfig,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Framework\View\Asset\Repository $assetRepo,
        \Magento\Framework\UrlInterface $urlBuilder,
        \Magento\Store\Model\StoreManagerInterface $storeManager,       
        \Magento\Framework\Image\AdapterFactory $imageFactory
    )
    {
        $this->_scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
                
        $this->_request = $request;
        $this->_assetRepo = $assetRepo;
        $this->_urlBuilder = $urlBuilder;
        $this->_filesystem = $filesystem;
        
        $this->_directory = $filesystem->getDirectoryWrite(DirectoryList::MEDIA);
        $this->_imageFactory = $imageFactory;
        parent::__construct($context);
    }

    // public function getImageUrl($image)
    // {
    //     $path = $this->_filesystem->getDirectoryRead(
    //         DirectoryList::MEDIA
    //     )->getAbsolutePath(
    //         'cp/events/images/resized/'
    //     );

    //     if ($image && file_exists($path . $image)) {
    //         $path = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
    //         return $path . 'cp/events/images/resized/' . $image;
    //     } 
    // }
      protected function getViewFileUrl($fileId, array $params = [])
    {
        try {
            $params = array_merge(['_secure' => $this->_request->isSecure()], $params);
            return $this->_assetRepo->getUrlWithParams($fileId, $params);
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            return $this->_urlBuilder->getUrl('', ['_direct' => 'core/index/notFound']);
        }
    }
}