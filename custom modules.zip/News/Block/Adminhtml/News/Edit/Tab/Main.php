<?php

namespace CP\News\Block\Adminhtml\News\Edit\Tab;

class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    protected $store;

    protected $_wysiwygConfig;
    protected $_helper;
    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        \Magento\Framework\Data\FormFactory $formFactory,
        \CP\News\Helper\Data $helper,
        array $data = []
    ) {
        $this->_wysiwygConfig = $wysiwygConfig;
        $this->_helper = $helper;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('news_item');

        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('news_');

        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('General Information'), 'class' => 'fieldset-wide']
        );

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }
        $fieldset->addField(
            'name',
            'text',
            [
                'name' => 'name',
                'label' => __('Name'),
                'title' => __('Name'),
                'required' => true
            ]
        );
 
        $fieldset->addField(
            'created_at',
            'date',
            [
                'name' => 'created_at',
                'label' => __('Date'),
                'title' => __('Date'),
                'required' => true,
                'date_format' => 'yyyy-MM-dd',
                'time_format' => 'hh:mm:ss',
                //'image'     => $this->getSkinUrl('images/grid-cal.gif'),
                'style' => 'display:inline-block; width: 100%; padding: 5px 10px;',
            ]
        );

        $fieldset->addField(
            'description',
            'editor',
            [
                'name' => 'description',
                'label' => __('Description'),
                'title' => __('Description'),
                'style'     => 'width:600px; height:300px;',
                'wysiwyg'   => true,
                'config'    => $this->_wysiwygConfig->getConfig(),
                
            ]
        );
 
        $fieldset->addField(
            'status',
            'select',
            [
                'label' => __('status'),
                'title' => __('status'),
                'name' => 'status',
                'required' => true,
                'options' => ['1' => __('Enabled'), '0' => __('Disabled')]
            ]
        );

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('General Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('General Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

    public function getAmountWord(){
        $html = '';
        $html .= '\'input-text required-entry validate-length maximum-length-' . $this->_helper->getAmountWord() .' minimum-length-1\'';
        return $html;
    }

    // public function getAfterImageElementHtml($field, $image)
    // {
    //     $html = '';
    //     $html .= '<p style="margin-top: 5px">';
    //     $html .= '<image style="min-width: 300px;" src="' . $this->_helper->getImageUrl($image) . '" />';
    //     //$html .= '<input type="hidden" value="' . $image . '" name="old_' . $field . '"/>';
    //     $html .= '</p>';
    //     return $html;
    // }
}
