<?php
namespace CP\News\Model;
class News extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
        $this->_init('CP\News\Model\ResourceModel\News');
    }
}

