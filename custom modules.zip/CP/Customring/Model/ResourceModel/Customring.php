<?php
namespace CP\Customring\Model\ResourceModel;

class Customring extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('customring', 'customring_id');
    }
}
?>