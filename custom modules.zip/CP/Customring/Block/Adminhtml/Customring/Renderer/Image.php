<?php
namespace CP\Customring\Block\Adminhtml\Customring\Renderer;

class Image extends \Magento\Framework\Data\Form\Element\AbstractElement
{
    

    public function getElementHtml()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 

        $customring = $objectManager->get('Magento\Framework\Registry')->registry('customring');
        $html = '';
        $image = $customring->getImage();
        
        if($image == ""){
            $html .= "Image not uploaded..";
        
        }else{
            $images = explode(',', $image);
            
            $mediaPath = $objectManager->get('Magento\Store\Model\StoreManagerInterface')
                        ->getStore()
                        ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
            foreach($images as $img)
            {
                $html .= "<img src = \"".$mediaPath."customring/".$img."\" height='100px' width='100px' /><br>";
            }
        }

        return $html;
    }
}