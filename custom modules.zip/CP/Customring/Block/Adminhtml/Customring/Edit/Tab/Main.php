<?php

namespace CP\Customring\Block\Adminhtml\Customring\Edit\Tab;

/**
 * Customring edit form main tab
 */
class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @var \CP\Customring\Model\Status
     */
    protected $_status;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \CP\Customring\Model\Status $status,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        /* @var $model \CP\Customring\Model\BlogPosts */
        $model = $this->_coreRegistry->registry('customring');

        $isElementDisabled = false;

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('customfield_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Item Information')]);

        if ($model->getId()) {
            $fieldset->addField('customring_id', 'hidden', ['name' => 'customring_id']);
        }

		
        $fieldset->addField(
            'name',
            'text',
            [
                'name' => 'name',
                'label' => __('Name'),
                'title' => __('Name'),
				
                'disabled' => $isElementDisabled
            ]
        );
					
        $fieldset->addField(
            'phone_number',
            'text',
            [
                'name' => 'phone_number',
                'label' => __('Phone Number'),
                'title' => __('Phone Number'),
				
                'disabled' => $isElementDisabled
            ]
        );
					
        $fieldset->addField(
            'email_id',
            'text',
            [
                'name' => 'email_id',
                'label' => __('Email'),
                'title' => __('Email'),
				
                'disabled' => $isElementDisabled
            ]
        );
		
        $fieldset->addField(
            'shape',
            'select',
            [
                'label' => __('Shape'),
                'title' => __('Shape'),
                'name' => 'shape',
                
                'options' => \CP\Customring\Block\Adminhtml\Customring\Grid::getOptionArray1(),
                'disabled' => $isElementDisabled
            ]
        );

        $fieldset->addField(
            'metal',
            'select',
            [
                'label' => __('Metal'),
                'title' => __('Metal'),
                'name' => 'metal',
                
                'options' => \CP\Customring\Block\Adminhtml\Customring\Grid::getOptionArray0(),
                'disabled' => $isElementDisabled
            ]
        );

        $fieldset->addField(
            'ring_size',
            'select',
            [
                'label' => __('Ring Size'),
                'title' => __('Ring Size'),
                'name' => 'ring_size',
                
                'options' => \CP\Customring\Block\Adminhtml\Customring\Grid::getOptionArray2(),
                'disabled' => $isElementDisabled
            ]
        );

        		
        $fieldset->addField(
            'description',
            'text',
            [
                'name' => 'description',
                'label' => __('Description'),
                'title' => __('Description'),
				
                'disabled' => $isElementDisabled
            ]
        );

        $fieldset->addType(
            'customer_images',
            '\CP\Customring\Block\Adminhtml\Customring\Renderer\Image'
        );  

        $fieldset->addField(
            'images',
            'customer_images',
            [
                'name'  => 'customer_images',
                'label' => __('Customer Images'),
                'title' => __('Customer Images'),
               
            ]
        );  
     
					

        if (!$model->getId()) {
            $model->setData('is_active', $isElementDisabled ? '0' : '1');
        }

        $form->setValues($model->getData());
        $this->setForm($form);
		
        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Item Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Item Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
    
    public function getTargetOptionArray(){
    	return array(
    				'_self' => "Self",
					'_blank' => "New Page",
    				);
    }
}
