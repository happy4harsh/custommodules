<?php
/**
 *
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CP\Customring\Controller\Index;

class Post extends \Magento\Framework\App\Action\Action
{

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    /**
     * @var \Magento\Framework\Translate\Inline\StateInterface
     */
    protected $inlineTranslation;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var \Magento\Framework\Escaper
     */
    protected $_escaper;
    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Escaper $escaper
    ) {
        parent::__construct($context);
        $this->_transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_escaper = $escaper;
    }
 
    public function execute()
    {
        
        $data = $this->getRequest()->getPostValue();
        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();  

        $fileSystem = $objectManager->create('\Magento\Framework\Filesystem');
        
        $mediaPath=$fileSystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath().'customring/';
        

        if (count($_FILES["image"]) > 0)
        {

            $folderName = $mediaPath;
            
            $counter = 0;
            $imageArray = array();

            for ($i = 0; $i < count($_FILES["image"]["name"]); $i++)
            {
                if ($_FILES["image"]["name"][$i] <> "")
                {
                    
                    $tmp = explode('.', $_FILES["image"]["name"][$i]);
                    $ext = end($tmp);
                    $imageName = rand(10000, 990000) . '_' . time() . '.' . $ext;
                    $imageArray[] = $imageName;
                    $filePath = $folderName . $imageName;

                    if (!move_uploaded_file($_FILES["image"]["tmp_name"][$i], $filePath))
                    {
                        $msg .= "Failed to upload" . $_FILES["image"]["name"][$i] . ". <br>";
                        $counter++;
                    }
                }
            }
        }

        $date = date('Y/m/d H:i:s');
        $data['image'] = implode(',', $imageArray);

        $data['created_at'] = $date;

        $support = $objectManager->create('CP\Customring\Model\Customring');

        $support->setData($data);
        $support->save();

        $this->inlineTranslation->suspend();
        try {

            $postObject = new \Magento\Framework\DataObject();
            $postObject->setData($data);

            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

            $sender_name = $this->scopeConfig->getValue('trans_email/ident_general/name', $storeScope);
            $sender_email = $this->scopeConfig->getValue('trans_email/ident_general/email', $storeScope);
            
            $error = false;

            $sender = [
                'name' => $this->_escaper->escapeHtml($sender_name),
                'email' => $this->_escaper->escapeHtml($sender_email),
            ];
            

            $transport = $this->_transportBuilder
                ->setTemplateIdentifier('send_email_email_template')
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ]
                )
                ->setTemplateVars(['data' => $postObject])
                ->setFrom($sender)
                ->addBcc($sender_email)
                ->addTo($data['email_id'])
                ->getTransport();

            $transport->sendMessage(); 
            
            $this->inlineTranslation->resume();
            $this->messageManager->addSuccess(
                __('Thanks for contacting us with your comments and questions. We\'ll respond to you very soon.')
            );

            $this->_redirect('*/*/');
            return;
        } catch (\Exception $e) {
            $this->inlineTranslation->resume();
            $this->messageManager->addError(
                __('We can\'t process your request right now. Sorry, that\'s all we know.'.$e->getMessage())
            );
            
            $this->_redirect('*/*/');
            return;
        }        
    }
}